# UnlimitedPeripheralWorks
[![Download UnlimitedPeripheralWorks on CurseForge](https://img.shields.io/static/v1?label=Download&message=Curseforge&color=E04E14&logoColor=E04E14&logo=CurseForge)][CurseForge]
[![DownloadUnlimitedPeripheralWorks on Modrinth](https://img.shields.io/static/v1?label=Download&color=00AF5C&logoColor=00AF5C&logo=Modrinth&message=Modrinth)][Modrinth]

This mod provide a lot of integrations and extension for minecraft and other mods! You can find list of available integrations and another features in [documentation](https://docs.siredvin.site/UnlimitedPeripheralWorks/)

[curseforge]: https://www.curseforge.com/minecraft/mc-mods/unlimitedperipheralworks "Download UnlimitedPeripheralWorks from CurseForge"
[modrinth]: https://modrinth.com/mod/unlimitedperipheralworks "Download UnlimitedPeripheralWork from Modrinth"
